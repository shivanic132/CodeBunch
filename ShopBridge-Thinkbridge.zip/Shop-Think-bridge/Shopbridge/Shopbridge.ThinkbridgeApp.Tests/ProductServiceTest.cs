﻿
using Microsoft.EntityFrameworkCore;
using Moq;
using Shopbridge.ThinkbridgeApp.Entity;
using Shopbridge.ThinkbridgeApp.Services;
using Shopbridge.ThinkbridgeApp.Services.Interfaces;
using System.Threading.Tasks;
using Xunit;

namespace Shopbridge.ThinkbridgeApp.Tests
{
    public class ProductServiceTest
    {
        private readonly IProductService _productService;
        private readonly Mock<ApplicationDbContext> _applicationDbContext;
        Mock<DbSet<Product>> _mockProductDBSet;

        public ProductServiceTest()
        {
            _applicationDbContext = new Mock<ApplicationDbContext>();
            _productService = new ProductService(_applicationDbContext.Object);
        }

        [Fact]
        public async Task Add_WhenCalled_Success()
        {
            //Arrange
            Product product = new Product()
            {
                ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1

            };
            _applicationDbContext.Setup(x => x.AddAsync(It.IsAny<Product>(), It.IsAny<System.Threading.CancellationToken>()));
            _applicationDbContext.Setup(x => x.SaveChangesAsync(It.IsAny<System.Threading.CancellationToken>()));

            //Act
            var respone = await _productService.Add(product);

            //Assert
            Assert.Equal(respone.ProductId, product.ProductId);
        }

        [Fact]
        public async Task Update_WhenCalled_Success()
        {
            //Arrange
            Product product = new Product()
            {
                ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1

            };
            _applicationDbContext.Setup(x => x.Update(It.IsAny<Product>()));
            _applicationDbContext.Setup(x => x.SaveChangesAsync(It.IsAny<System.Threading.CancellationToken>()));

            //Act
            var respone = await _productService.Add(product);

            //Assert
            Assert.Equal(respone.ProductId, product.ProductId);
        }        
    }
}
