
using Moq;
using Shopbridge.ThinkbridgeApp.Controllers;
using Shopbridge.ThinkbridgeApp.Entity;
using Shopbridge.ThinkbridgeApp.Services.Interfaces;
using System;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Shopbridge.ThinkbridgeApp.Tests
{
    public class ProductControllerTest
    {
        private readonly ProductController _productController;
        private readonly Mock<IProductService> _productService;        

        public ProductControllerTest()
        {
            _productService = new Mock<IProductService>();
            _productController = new ProductController(_productService.Object);
        }

        [Fact]
        public void Add_WhenCalled_Post_Ok()
        {
            //Arrange
            Product product = new Product()
            {
                ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1

            };
            var productdata = Task<Product>.Factory.StartNew(() =>
            {
                Product productdetail = product;
                return productdetail;
            });
            _productService.Setup(x => x.Add(product)).Returns(productdata);
            var expectedStatusCode = (int)HttpStatusCode.OK;

            //Act
            var response = _productController.Post(product);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response.Result.Result).StatusCode;

            //Assert               
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void Add_WhenCalled_Post_BadRequest()
        {
            //Arrange
            Product product = null;
            var productdata = Task<Product>.Factory.StartNew(() =>
            {
                Product productdetail = product;
                return productdetail;
            });
            _productService.Setup(x => x.Add(product)).Returns(productdata);
            var expectedStatusCode = (int)HttpStatusCode.BadRequest;

            //Act
            var response = _productController.Post(product);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)response.Result.Result).StatusCode;

            //Assert               
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void Add_WhenCalled_Post_InternalServerError()
        {
            //Arrange
            Product product = new Product()
            {
                ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1

            };
            var productdata = Task<Product>.Factory.StartNew(() =>
            {
                Product productdetail = product;
                return productdetail;
            });
            Exception exception = new Exception();
            _productService.Setup(x => x.Add(product)).Throws(exception);
            var expectedStatusCode = (int)HttpStatusCode.InternalServerError;

            //Act
            var response = _productController.Post(product);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response.Result.Result).StatusCode;

            //Assert               
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void Update_WhenCalled_Update_Ok()
        {
            //Arrange
            Product product = new Product()
            {
                ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1

            };
            var productdata = Task<Product>.Factory.StartNew(() =>
            {
                Product productdetail = product;
                return productdetail;
            });
            _productService.Setup(x => x.Update(product)).Returns(productdata);
            var expectedStatusCode = (int)HttpStatusCode.OK;

            //Act
            var response = _productController.Update(product);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response.Result.Result).StatusCode;

            //Assert               
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void Update_WhenCalled_Update_BadRequest()
        {
            //Arrange
            Product product = null;
            var productdata = Task<Product>.Factory.StartNew(() =>
            {
                Product productdetail = product;
                return productdetail;
            });
            _productService.Setup(x => x.Update(product)).Returns(productdata);
            var expectedStatusCode = (int)HttpStatusCode.BadRequest;

            //Act
            var response = _productController.Update(product);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)response.Result.Result).StatusCode;

            //Assert               
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void Update_WhenCalled_Update_InternalServerError()
        {
            //Arrange
            Product product = new Product()
            {
                ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1

            };
            var productdata = Task<Product>.Factory.StartNew(() =>
            {
                Product productdetail = product;
                return productdetail;
            });
            Exception exception = new Exception();
            _productService.Setup(x => x.Update(product)).Throws(exception);
            var expectedStatusCode = (int)HttpStatusCode.InternalServerError;

            //Act
            var response = _productController.Update(product);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response.Result.Result).StatusCode;

            //Assert               
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void GetAll_WhenCalled_GetAll_Ok()
        {
            //Arrange
            Product[] products = new Product[]
            {
                new Product
                {
                    ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1
                }
            };

            _productService.Setup(x => x.GetAllProducts()).Returns(products);
            var expectedStatusCode = (int)HttpStatusCode.OK;

            //Act
            var response = _productController.GetAll();
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void GetAll_WhenCalled_GetAll_InternalServerError()
        {
            //Arrange
            Product[] products = null;

            _productService.Setup(x => x.GetAllProducts()).Returns(products);
            var expectedStatusCode = (int)HttpStatusCode.InternalServerError;

            //Act
            var response = _productController.GetAll();
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void GetAll_WhenCalled_GetAll_NotFound()
        {
            //Arrange
            Product[] products = new Product[] { };

            _productService.Setup(x => x.GetAllProducts()).Returns(products);
            var expectedStatusCode = (int)HttpStatusCode.NotFound;

            //Act
            var response = _productController.GetAll();
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void GetProductById_WhenCalled_GetProductById_Ok()
        {
            //Arrange
            string ProductId = "P101";

            Product[] products = new Product[]
            {
                new Product
                {
                    ProductId = "P101",
                ProductName = "Product",
                CategoryId = 1,
                Price = 100,
                QuantityAvailable = 1
                }
            };

            _productService.Setup(x => x.GetById(ProductId)).Returns(products);
            var expectedStatusCode = (int)HttpStatusCode.OK;

            //Act
            var response = _productController.GetProductById(ProductId);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void GetProductById_WhenCalled_GetProductById_NotFound()
        {
            //Arrange
            string ProductId = "P101";

            Product[] products = new Product[]
            {
            };

            _productService.Setup(x => x.GetById(ProductId)).Returns(products);
            var expectedStatusCode = (int)HttpStatusCode.NotFound;

            //Act
            var response = _productController.GetProductById(ProductId);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void GetProductById_WhenCalled_GetProductById_InternalServerError()
        {
            //Arrange
            string ProductId = "P101";

            Product[] products = null;

            _productService.Setup(x => x.GetById(ProductId)).Returns(products);
            var expectedStatusCode = (int)HttpStatusCode.InternalServerError;

            //Act
            var response = _productController.GetProductById(ProductId);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void DeleteProduct_WhenCalled_Delete_Ok()
        {
            //Arrange
            string ProductId = "P101";

            _productService.Setup(x => x.Delete(ProductId)).Returns(true);
            var expectedStatusCode = (int)HttpStatusCode.OK;

            //Act
            var response = _productController.DeleteProduct(ProductId);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void DeleteProduct_WhenCalled_Delete_NotFound()
        {
            //Arrange
            string ProductId = "P101";

            _productService.Setup(x => x.Delete(ProductId)).Returns(false);
            var expectedStatusCode = (int)HttpStatusCode.NotFound;

            //Act
            var response = _productController.DeleteProduct(ProductId);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

        [Fact]
        public void DeleteProduct_WhenCalled_Delete_InternalServerError()
        {
            //Arrange
            string ProductId = "P101";
            Exception exception = new Exception();
            _productService.Setup(x => x.Delete(ProductId)).Throws(exception);
            var expectedStatusCode = (int)HttpStatusCode.InternalServerError;

            //Act
            var response = _productController.DeleteProduct(ProductId);
            var actualstatuscode = ((Microsoft.AspNetCore.Mvc.ObjectResult)response).StatusCode;

            //Assert                           
            Assert.Equal(Convert.ToString(expectedStatusCode), Convert.ToString(actualstatuscode));
        }

    }
}

