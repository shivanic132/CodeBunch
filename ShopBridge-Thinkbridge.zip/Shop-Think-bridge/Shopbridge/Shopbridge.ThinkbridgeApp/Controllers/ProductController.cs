﻿using Microsoft.AspNetCore.Mvc;
using Shopbridge.ThinkbridgeApp.Entity;
using Shopbridge.ThinkbridgeApp.Services.Interfaces;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Shopbridge.ThinkbridgeApp.Controllers
{
    
    [Route("Shopbridge/[controller]")]
    [ApiController]
    public class ProductController:ControllerBase
    {
        private readonly IProductService _productService;
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        #region API Methods

        /// <summary>
        ///This endpoint will Insert Record in Products table.
        /// </summary>
        [HttpPost]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(Product))]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.PreconditionFailed)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<Product>> Post([FromBody] Product request)
        {            
            try
            {
                if (ModelState.IsValid && request != null)
                {                    
                    return this.Ok(await _productService.Add(request));
                }
                else
                {                    
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {                
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.InnerException);
            }
        }

        /// <summary>
        ///This endpoint will Update Record in Products table.
        /// </summary>
        [HttpPut]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(Product))]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]      
        public async Task<ActionResult<Product>> Update([FromBody] Product request)
        {
            try
            {
                if (ModelState.IsValid && request != null)
                {                    
                    var result = await _productService.Update(request);
                    return this.Ok(result);
                }
                else
                {                    
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {                
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        /// <summary>
        ///This endpoint will Getl All Record from Products table.
        /// </summary>
        [HttpGet]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(Product))]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public ActionResult GetAll()
        {
            try
            {               
                var result = _productService.GetAllProducts();
                if (result.Cast<object>().Any()) 
                { 
                    return this.Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        /// <summary>
        ///This endpoint will Get Record by Id from Products table.
        /// </summary>
        [HttpGet]
        [Route("{Id}")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(Product))]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public ActionResult GetProductById(string Id)
        {
            try
            {
                var result = _productService.GetById(Id);
                if (result.Count() > 0)
                {
                    return this.Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }


        /// <summary>
        ///This endpoint will delete Record by Id from Products table.
        /// </summary>
        [HttpDelete]
        [Route("{Id}")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(Product))]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public ActionResult DeleteProduct(string Id)
        {
            try
            {
                bool IsDeleted= _productService.Delete(Id);
                if (IsDeleted)
                {
                    return StatusCode((int)HttpStatusCode.OK, "Recored deleted for " + Id);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.NotFound, "Recored not found for " + Id);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        #endregion
    }
}
