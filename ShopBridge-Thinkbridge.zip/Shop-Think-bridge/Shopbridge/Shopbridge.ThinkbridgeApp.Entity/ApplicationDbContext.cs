﻿
using Microsoft.EntityFrameworkCore;

namespace Shopbridge.ThinkbridgeApp.Entity
{
   public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public ApplicationDbContext()
        {

        }
        public DbSet<Product> Product { get; set; }
    }
}
