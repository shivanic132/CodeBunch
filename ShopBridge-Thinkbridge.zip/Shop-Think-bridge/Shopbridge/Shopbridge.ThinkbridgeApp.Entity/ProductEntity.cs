﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace Shopbridge.ThinkbridgeApp.Entity
{
    [Table("Products")]
    public class Product
   {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        public int Price { get; set; }
        public int QuantityAvailable { get; set; }
    }
}
