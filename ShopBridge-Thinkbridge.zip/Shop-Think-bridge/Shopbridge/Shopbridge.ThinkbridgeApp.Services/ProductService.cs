﻿using Shopbridge.ThinkbridgeApp.Entity;
using Shopbridge.ThinkbridgeApp.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge.ThinkbridgeApp.Services
{
    [ExcludeFromCodeCoverage]
    public class ProductService : IProductService
    {
        private readonly ApplicationDbContext _dbContext;
       
        public ProductService(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        //Add product to the table
        public async Task<Product> Add(Product productEntity)
        {
            try
            {
                await _dbContext.AddAsync(productEntity);
                await _dbContext.SaveChangesAsync();
                return productEntity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //Update product details in the table
        public async Task<Product> Update(Product product)
        {
            try
            {
                _dbContext.Product.Update(product);
                await _dbContext.SaveChangesAsync();
                return product;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //Get all products list
        public IEnumerable<Product> GetAllProducts()
        {
            try
            {
                return _dbContext.Product.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

        }


        ////Get product details by id
        public IEnumerable<Product> GetById(string Id)
        {
            try
            {
                var productdetails = _dbContext.Product.Where(x => x.ProductId == Id);
                return productdetails;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        //Delete products from table
        public bool Delete(string Id)
        {
            bool Isdelele = false;
            try
            {
                var productDetails = _dbContext.Product.Where(x => x.ProductId == Id).ToList();
                foreach(var item in productDetails)
                {
                    _dbContext.Remove(item);
                    _dbContext.SaveChanges();
                }
                Isdelele = true;                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return Isdelele;
        }

    }
}
