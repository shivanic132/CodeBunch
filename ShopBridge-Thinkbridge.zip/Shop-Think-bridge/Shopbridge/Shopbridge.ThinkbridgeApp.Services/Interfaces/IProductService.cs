﻿using Shopbridge.ThinkbridgeApp.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Shopbridge.ThinkbridgeApp.Services.Interfaces
{
  public  interface IProductService
    {
        public Task<Product> Add(Product productEntity);

        public Task<Product> Update(Product productEntity);

        public IEnumerable<Product> GetAllProducts();

        public IEnumerable<Product> GetById(string Id);

        public bool Delete(string Id);
    }
}
